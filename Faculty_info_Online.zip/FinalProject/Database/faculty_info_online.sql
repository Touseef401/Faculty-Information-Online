-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2024 at 03:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty_info_online`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(225) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `password`, `email`) VALUES
(1, 'touseef', '1234567', 'abcd@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `cnic` varchar(15) NOT NULL,
  `department` varchar(100) NOT NULL,
  `date_of_joining` date NOT NULL,
  `latest_academic_degree` varchar(100) NOT NULL,
  `experties` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(225) DEFAULT NULL,
  `contact_no` varchar(15) NOT NULL,
  `landline_no` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_id` int(11) DEFAULT NULL,
  `date_of_birth` date NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `name`, `age`, `cnic`, `department`, `date_of_joining`, `latest_academic_degree`, `experties`, `email`, `password`, `contact_no`, `landline_no`, `status`, `updated_at`, `admin_id`, `date_of_birth`, `gender`) VALUES
(28, 'wahab', 24, '87498784383783', 'computer science', '2024-12-26', 'adp web development', 'physics', 'wahab@gmail.com', 'hA#jPgW3', '+92-331-8435573', '+92-058-3489435', 'active', '2024-12-26 07:30:51', NULL, '2000-12-26', 'male'),
(29, 'Asif raza', 44, '39848-8387487-2', 'English', '2008-12-26', 'M Phil English', 'English', 'abcd@gmail.com', 'u0rK1I3Y', '+92-331-8744320', '+92-058-4299774', 'active', '2024-12-26 07:42:02', NULL, '1980-04-04', 'male'),
(30, 'Mahwish Ali', 44, '39848-1234567-2', 'biology', '2013-12-12', 'MBBS', 'Biology', 'Mawishali@gmail.com', '9yI6TIvk', '+92-331-6825354', '+92-058-7687988', 'active', '2024-12-28 19:47:05', NULL, '1980-09-06', 'female'),
(31, 'Rana Naveed', 24, '39848-7726655-2', 'accounitng', '2024-12-29', 'BBA', 'Math', 'RanaNaveed@gmail.com', 'ft^R3wig', '+92-331-8983736', '+92-058-7364977', 'inactive', '2024-12-28 19:49:32', NULL, '2000-02-02', 'male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`(50));

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `cnic` (`cnic`),
  ADD UNIQUE KEY `admin_id` (`admin_id`),
  ADD UNIQUE KEY `email` (`email`(50));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
